# Steff Dowle Mentoring Website

This is a Vite + React website ready to deploy on Vercel.

## Upload to GitHub
1. Create a new GitHub repository called `steff-dowle-mentoring`.
2. Upload all files and folders from this project.
3. Commit the files.

## Deploy on Vercel
1. Go to Vercel.
2. Click Add New > Project.
3. Import the GitHub repository.
4. Leave settings as default.
5. Click Deploy.

## Edit contact details
Open `src/App.jsx` and replace:
- `07XXX XXXXXX`
- `enquiries@example.co.uk`
